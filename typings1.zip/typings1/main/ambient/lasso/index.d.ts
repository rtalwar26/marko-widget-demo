declare module Lasso{

   export function configure(...args)
}
declare module "lasso" {
    export = Lasso;
}